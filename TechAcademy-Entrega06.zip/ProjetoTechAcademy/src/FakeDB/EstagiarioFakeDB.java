package FakeDB;

import java.util.ArrayList;

import Dominio.Estagiario;

public class EstagiarioFakeDB extends AbsGenericFakeDB<Estagiario>{

    @Override
    protected void autoPreencher(){
        this.dados.add(new Estagiario(301, "Gabriel Matos", "3011", "gabriel.matos@email.com", "67998220001", "Rua Ceará, 12", 1200.00, 20, "Suporte Técnico"));
        this.dados.add(new Estagiario(302, "Larissa Quintino", "3012", "larissa.q@email.com", "67998220002", "Av. Afonso Pena, 900", 1500.00, 30, "Desenvolvimento"));
        this.dados.add(new Estagiario(303, "Bruno Teixeira", "3013", "bruno.t@email.com", "67998220003", "Rua Pará, 33", 1000.00, 20, "Secretaria Acadêmica"));
    }

    public EstagiarioFakeDB(){
        this.dados = new ArrayList<>();
        this.autoPreencher();
    }
}
