package FakeDB;

import java.util.ArrayList;

import Dominio.Egresso;

public class EgressoFakeDB extends AbsGenericFakeDB<Egresso>{

    @Override
    protected void autoPreencher(){
        this.dados.add(new Egresso(401, "Fernanda Souza", "4011", 2019, "Ciência da Computação", "Desenvolvimento de Software"));
        this.dados.add(new Egresso(402, "Rafael Nogueira", "4012", 2021, "Análise e Desenvolvimento de Sistemas", "Infraestrutura de TI"));
        this.dados.add(new Egresso(403, "Beatriz Tavares", "4013", 2022, "Sistemas de Informação", "Ciência de Dados"));
        this.dados.add(new Egresso(404, "Thiago Ramos", "4014", 2020, "Engenharia de Software", "Segurança da Informação"));
    }

    public EgressoFakeDB(){
        this.dados = new ArrayList<>();
        this.autoPreencher();
    }
}
