package FakeDB;

import java.util.ArrayList;

import Dominio.Visitante;

public class VisitanteFakeDB extends AbsGenericFakeDB<Visitante>{

    @Override
    protected void autoPreencher(){
        this.dados.add(new Visitante(201, "Helena Prado", "2011", "helena.prado@email.com", "67999110001", "Rua das Flores, 100", "Reunião com a coordenação", 1, "Coordenação"));
        this.dados.add(new Visitante(202, "Otávio Campos", "2012", "otavio.campos@email.com", "67999110002", "Av. Brasil, 250", "Entrega de equipamentos", 2, "Almoxarifado"));
        this.dados.add(new Visitante(203, "Priscila Duarte", "2013", "priscila.duarte@email.com", "67999110003", "Rua Bahia, 45", "Manutenção de rede", 3, "Laboratório de Informática"));
        this.dados.add(new Visitante(204, "Renato Figueiredo", "2014", "renato.fig@email.com", "67999110004", "Rua Goiás, 78", "Palestra aos alunos", 4, "Auditório"));
    }

    public VisitanteFakeDB(){
        this.dados = new ArrayList<>();
        this.autoPreencher();
    }
}
