package Teste;

import Dominio.Egresso;
import Servico.EgressoServ;

public class EgressoTest {

    public static void main(String[] args) {
        Verificador v = new Verificador();
        EgressoServ serv = new EgressoServ();

        System.out.println("=== Teste Egresso ===");

        // Carga inicial
        v.verificar("Carga inicial possui pelo menos 3 registros", serv.listar().size() >= 3);
        int qtdInicial = serv.listar().size();

        // CREATE
        Egresso novo = new Egresso(0, "Teste Silva", "999", 2024, "Curso X", "Area X");
        Egresso criado = serv.adicionar(novo);
        v.verificar("Create: retorna o objeto cadastrado", criado != null);
        v.verificar("Create: gera código maior que zero", criado.getCodigo() > 0);
        v.verificar("Create: lista cresceu em 1", serv.listar().size() == qtdInicial + 1);

        // READ
        Egresso lido = serv.buscar(criado.getCodigo());
        v.verificar("ReadOne: encontra pelo código", lido != null && lido.getNome().equals("Teste Silva"));
        v.verificar("ReadOne: código inexistente retorna null", serv.buscar(99999) == null);

        // UPDATE
        Egresso alterado = new Egresso(0, "Teste Alterado", "999", 2025, "Curso Y", "Area Y");
        alterado.setCodigo(criado.getCodigo());
        Egresso retornoUpdate = serv.editar(alterado);
        v.verificar("Update: retorna o objeto alterado", retornoUpdate != null);
        v.verificar("Update: dados persistidos", serv.buscar(criado.getCodigo()).getNome().equals("Teste Alterado"));
        v.verificar("Update: tamanho da lista não muda", serv.listar().size() == qtdInicial + 1);
        Egresso inexistente = new Egresso(0, "Teste Alterado", "999", 2025, "Curso Y", "Area Y");
        inexistente.setCodigo(99999);
        v.verificar("Update: código inexistente retorna null", serv.editar(inexistente) == null);

        // DELETE
        Egresso apagado = serv.excluir(serv.buscar(criado.getCodigo()));
        v.verificar("Delete: retorna o objeto removido", apagado != null);
        v.verificar("Delete: registro não é mais encontrado", serv.buscar(criado.getCodigo()) == null);
        v.verificar("Delete: lista volta ao tamanho inicial", serv.listar().size() == qtdInicial);

        // Polimorfismo: exibir() sobrescrito
        System.out.println("  Exibição polimórfica dos registros:");
        for (Egresso item : serv.listar()) {
            item.exibir();
        }

        v.resumo("EgressoTest");
    }
}
