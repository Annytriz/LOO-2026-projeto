package Teste;

/** Auxiliar simples para as classes de teste (sem dependência de JUnit). */
public class Verificador {
    private int total = 0;
    private int falhas = 0;

    public void verificar(String descricao, boolean condicao){
        this.total++;
        if (condicao){
            System.out.println("  [OK]    " + descricao);
        } else {
            this.falhas++;
            System.out.println("  [FALHA] " + descricao);
        }
    }

    public void resumo(String nome){
        System.out.println(nome + ": " + (this.total - this.falhas) + "/" + this.total + " verificações passaram.");
        if (this.falhas > 0){
            System.exit(1);
        }
    }
}
