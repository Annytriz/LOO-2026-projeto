package Teste;

import Dominio.Estagiario;
import Servico.EstagiarioServ;

public class EstagiarioTest {

    public static void main(String[] args) {
        Verificador v = new Verificador();
        EstagiarioServ serv = new EstagiarioServ();

        System.out.println("=== Teste Estagiario ===");

        // Carga inicial
        v.verificar("Carga inicial possui pelo menos 3 registros", serv.listar().size() >= 3);
        int qtdInicial = serv.listar().size();

        // CREATE
        Estagiario novo = new Estagiario(0, "Teste Silva", "999", "t@t.com", "6700000000", "Rua T", 900.0, 20, "TI");
        Estagiario criado = serv.adicionar(novo);
        v.verificar("Create: retorna o objeto cadastrado", criado != null);
        v.verificar("Create: gera código maior que zero", criado.getCodigo() > 0);
        v.verificar("Create: lista cresceu em 1", serv.listar().size() == qtdInicial + 1);

        // READ
        Estagiario lido = serv.buscar(criado.getCodigo());
        v.verificar("ReadOne: encontra pelo código", lido != null && lido.getNome().equals("Teste Silva"));
        v.verificar("ReadOne: código inexistente retorna null", serv.buscar(99999) == null);

        // UPDATE
        Estagiario alterado = new Estagiario(0, "Teste Alterado", "999", "t2@t.com", "6711111111", "Rua T2", 950.0, 25, "RH");
        alterado.setCodigo(criado.getCodigo());
        Estagiario retornoUpdate = serv.editar(alterado);
        v.verificar("Update: retorna o objeto alterado", retornoUpdate != null);
        v.verificar("Update: dados persistidos", serv.buscar(criado.getCodigo()).getNome().equals("Teste Alterado"));
        v.verificar("Update: tamanho da lista não muda", serv.listar().size() == qtdInicial + 1);
        Estagiario inexistente = new Estagiario(0, "Teste Alterado", "999", "t2@t.com", "6711111111", "Rua T2", 950.0, 25, "RH");
        inexistente.setCodigo(99999);
        v.verificar("Update: código inexistente retorna null", serv.editar(inexistente) == null);

        // DELETE
        Estagiario apagado = serv.excluir(serv.buscar(criado.getCodigo()));
        v.verificar("Delete: retorna o objeto removido", apagado != null);
        v.verificar("Delete: registro não é mais encontrado", serv.buscar(criado.getCodigo()) == null);
        v.verificar("Delete: lista volta ao tamanho inicial", serv.listar().size() == qtdInicial);

        // Polimorfismo: exibir() sobrescrito
        System.out.println("  Exibição polimórfica dos registros:");
        for (Estagiario item : serv.listar()) {
            item.exibir();
        }

        v.resumo("EstagiarioTest");
    }
}
