package Teste;

import Dominio.Visitante;
import Servico.VisitanteServ;

public class VisitanteTest {

    public static void main(String[] args) {
        Verificador v = new Verificador();
        VisitanteServ serv = new VisitanteServ();

        System.out.println("=== Teste Visitante ===");

        // Carga inicial
        v.verificar("Carga inicial possui pelo menos 3 registros", serv.listar().size() >= 3);
        int qtdInicial = serv.listar().size();

        // CREATE
        Visitante novo = new Visitante(0, "Teste Silva", "999", "t@t.com", "6700000000", "Rua T", "Teste", 99, "Setor T");
        Visitante criado = serv.adicionar(novo);
        v.verificar("Create: retorna o objeto cadastrado", criado != null);
        v.verificar("Create: gera código maior que zero", criado.getCodigo() > 0);
        v.verificar("Create: lista cresceu em 1", serv.listar().size() == qtdInicial + 1);

        // READ
        Visitante lido = serv.buscar(criado.getCodigo());
        v.verificar("ReadOne: encontra pelo código", lido != null && lido.getNome().equals("Teste Silva"));
        v.verificar("ReadOne: código inexistente retorna null", serv.buscar(99999) == null);

        // UPDATE
        Visitante alterado = new Visitante(0, "Teste Alterado", "999", "t2@t.com", "6711111111", "Rua T2", "Teste2", 98, "Setor T2");
        alterado.setCodigo(criado.getCodigo());
        Visitante retornoUpdate = serv.editar(alterado);
        v.verificar("Update: retorna o objeto alterado", retornoUpdate != null);
        v.verificar("Update: dados persistidos", serv.buscar(criado.getCodigo()).getNome().equals("Teste Alterado"));
        v.verificar("Update: tamanho da lista não muda", serv.listar().size() == qtdInicial + 1);
        Visitante inexistente = new Visitante(0, "Teste Alterado", "999", "t2@t.com", "6711111111", "Rua T2", "Teste2", 98, "Setor T2");
        inexistente.setCodigo(99999);
        v.verificar("Update: código inexistente retorna null", serv.editar(inexistente) == null);

        // DELETE
        Visitante apagado = serv.excluir(serv.buscar(criado.getCodigo()));
        v.verificar("Delete: retorna o objeto removido", apagado != null);
        v.verificar("Delete: registro não é mais encontrado", serv.buscar(criado.getCodigo()) == null);
        v.verificar("Delete: lista volta ao tamanho inicial", serv.listar().size() == qtdInicial);

        // Polimorfismo: exibir() sobrescrito
        System.out.println("  Exibição polimórfica dos registros:");
        for (Visitante item : serv.listar()) {
            item.exibir();
        }

        v.resumo("VisitanteTest");
    }
}
