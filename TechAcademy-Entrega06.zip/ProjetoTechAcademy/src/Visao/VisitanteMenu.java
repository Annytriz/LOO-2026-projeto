package Visao;

import java.util.ArrayList;
import java.util.Scanner;

import Dominio.Visitante;
import Servico.VisitanteServ;
import Tools.Util;

public class VisitanteMenu extends AbsMenu {

    private VisitanteServ servico;

    @Override
    public void executar(){
        int opcao = 0;
        try {
            while (opcao != 6) {
                System.out.println("\n");
                opcao = this.exibirMenu();
                switch (opcao) {
                    case 1:
                        this.cadastrar();
                        this.pausar();
                        break;
                    case 2:
                        this.listar();
                        this.pausar();
                        break;
                    case 3:
                        this.buscarPorCodigo();
                        this.pausar();
                        break;
                    case 4:
                        this.editar();
                        this.pausar();
                        break;
                    case 5:
                        this.excluir();
                        this.pausar();
                        break;
                    case 6:
                        System.out.println("Encerrando o menu de visitantes. Até logo!");
                        break;
                    default:
                        System.out.println("Opção inválida! Escolha um número de 1 a 6.");
                        this.pausar();
                        break;
                }
                if (opcao != 6) {
                    Util.limparTerminal();
                }
            }
        } catch (java.util.NoSuchElementException e) {
            // Entrada encerrada (Ctrl+D / fim do stdin): sai sem erro.
            System.out.println("\nEntrada encerrada. Saindo do menu.");
        }
    }

    // ---------- menu e leitura validada ----------

    private int exibirMenu(){
        System.out.println("----- MENU [VISITANTE] -----");
        System.out.println("1 - Cadastrar visitante");
        System.out.println("2 - Listar todos os visitantes");
        System.out.println("3 - Buscar visitante por código");
        System.out.println("4 - Editar visitante");
        System.out.println("5 - Excluir visitante");
        System.out.println("6 - Sair");
        return this.lerInt("Selecione uma opção: ");
    }

    /** Lê um inteiro; repete a pergunta enquanto a entrada for inválida. Nunca lança NumberFormatException. */
    private int lerInt(String mensagem){
        while (true) {
            System.out.print(mensagem);
            String texto = this.scan.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida! Digite um número inteiro.");
            }
        }
    }

    /** Lê um inteiro maior ou igual a zero (usado no nº do crachá). */
    private int lerInteiroPositivo(String mensagem){
        while (true) {
            int valor = this.lerInt(mensagem);
            if (valor >= 0) {
                return valor;
            }
            System.out.println("O valor não pode ser negativo.");
        }
    }

    /** Lê um texto não vazio (aceita espaços, ex.: "Rua das Flores, 100"). */
    private String lerTexto(String mensagem){
        while (true) {
            System.out.print(mensagem);
            String texto = this.scan.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("Este campo não pode ficar vazio.");
        }
    }

    /** Pergunta S/N e devolve true para sim. */
    private boolean confirmar(String mensagem){
        while (true) {
            System.out.print(mensagem + " (S/N): ");
            String resposta = this.scan.nextLine().trim().toUpperCase();
            if (resposta.equals("S") || resposta.equals("SIM")) {
                return true;
            }
            if (resposta.equals("N") || resposta.equals("NAO") || resposta.equals("NÃO")) {
                return false;
            }
            System.out.println("Responda com S ou N.");
        }
    }

    // ---------- operações ----------

    private void cadastrar(){
        System.out.println("\n***** CADASTRAR VISITANTE *****");
        String nome = this.lerTexto("Nome: ");
        String cpf = this.lerTexto("CPF: ");
        String email = this.lerTexto("E-mail: ");
        String telefone = this.lerTexto("Telefone: ");
        String endereco = this.lerTexto("Endereço: ");
        String motivo = this.lerTexto("Motivo da visita: ");
        int cracha = this.lerInteiroPositivo("Número do crachá: ");
        String setor = this.lerTexto("Setor da visita: ");

        Visitante novo = new Visitante(0, nome, cpf, email, telefone, endereco, motivo, cracha, setor);
        novo = this.servico.adicionar(novo);
        System.out.println("\nVisitante cadastrado com sucesso:");
        novo.exibir();
    }

    private void listar(){
        System.out.println("\n***** LISTA DE VISITANTES *****");
        ArrayList<Visitante> lista = this.servico.listar();
        if (lista.isEmpty()) {
            System.out.println("Nenhum visitante cadastrado.");
            return;
        }
        for (Visitante item : lista) {
            item.exibir();
            System.out.println();
        }
        System.out.println("Total: " + lista.size() + " visitante(s).");
    }

    private void buscarPorCodigo(){
        System.out.println("\n***** BUSCAR VISITANTE POR CÓDIGO *****");
        int codigo = this.lerInt("Digite o código: ");
        Visitante encontrado = this.servico.buscar(codigo);
        if (encontrado != null) {
            encontrado.exibir();
        } else {
            System.out.println("Visitante não encontrado para o código " + codigo + ".");
        }
    }

    private void editar(){
        System.out.println("\n***** EDITAR VISITANTE *****");
        int codigo = this.lerInt("Digite o código do visitante: ");
        Visitante atual = this.servico.buscar(codigo);
        if (atual == null) {
            System.out.println("Visitante não encontrado para o código " + codigo + ".");
            return;
        }
        System.out.println("Dados atuais:");
        atual.exibir();

        // Trabalha em uma cópia: nada muda no repositório até o usuário escolher "Salvar".
        Visitante copia = new Visitante(atual.getCodigo(), atual.getNome(), atual.getCpf(),
                atual.getEmail(), atual.getTelefone(), atual.getEndereco(),
                atual.getMotivoVisita(), atual.getCrachaNumero(), atual.getSetorVisita());

        int opcao = -1;
        while (opcao != 9 && opcao != 0) {
            System.out.println("\nO que deseja alterar?");
            System.out.println("1 - Nome");
            System.out.println("2 - CPF");
            System.out.println("3 - E-mail");
            System.out.println("4 - Telefone");
            System.out.println("5 - Endereço");
            System.out.println("6 - Motivo da visita");
            System.out.println("7 - Número do crachá");
            System.out.println("8 - Setor da visita");
            System.out.println("9 - Salvar alterações");
            System.out.println("0 - Cancelar (descartar alterações)");
            opcao = this.lerInt("Selecione um campo: ");
            switch (opcao) {
                case 1: copia.setNome(this.lerTexto("Novo nome: ")); break;
                case 2: copia.setCpf(this.lerTexto("Novo CPF: ")); break;
                case 3: copia.setEmail(this.lerTexto("Novo e-mail: ")); break;
                case 4: copia.setTelefone(this.lerTexto("Novo telefone: ")); break;
                case 5: copia.setEndereco(this.lerTexto("Novo endereço: ")); break;
                case 6: copia.setMotivoVisita(this.lerTexto("Novo motivo da visita: ")); break;
                case 7: copia.setCrachaNumero(this.lerInteiroPositivo("Novo número do crachá: ")); break;
                case 8: copia.setSetorVisita(this.lerTexto("Novo setor da visita: ")); break;
                case 9:
                    Visitante salvo = this.servico.editar(copia);
                    if (salvo != null) {
                        System.out.println("Visitante atualizado com sucesso:");
                        salvo.exibir();
                    } else {
                        System.out.println("Erro: não foi possível atualizar o visitante.");
                    }
                    break;
                case 0:
                    System.out.println("Edição cancelada. Nenhuma alteração foi salva.");
                    break;
                default:
                    System.out.println("Opção inválida!");
                    break;
            }
        }
    }

    private void excluir(){
        System.out.println("\n***** EXCLUIR VISITANTE *****");
        int codigo = this.lerInt("Digite o código do visitante: ");
        Visitante alvo = this.servico.buscar(codigo);
        if (alvo == null) {
            System.out.println("Visitante não encontrado para o código " + codigo + ".");
            return;
        }
        alvo.exibir();
        if (this.confirmar("Confirma a exclusão deste visitante?")) {
            Visitante removido = this.servico.excluir(alvo);
            if (removido != null) {
                System.out.println("Visitante excluído com sucesso.");
            } else {
                System.out.println("Erro: não foi possível excluir o visitante.");
            }
        } else {
            System.out.println("Exclusão cancelada.");
        }
    }

    public VisitanteMenu(){
        this.servico = new VisitanteServ();
        this.scan = new Scanner(System.in);
    }
}
