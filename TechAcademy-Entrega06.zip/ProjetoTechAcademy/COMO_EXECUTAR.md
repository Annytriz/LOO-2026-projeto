# Como executar (Entrega 06)

Na pasta ProjetoTechAcademy:

    # compilar
    mkdir -p bin && javac -encoding UTF-8 -d bin $(find src -name '*.java')   # Linux/Mac
    # Windows (PowerShell): javac -encoding UTF-8 -d bin (Get-ChildItem -Recurse src -Filter *.java).FullName

    # menu interativo de Visitante
    java -cp bin App

    # testes
    java -cp bin Teste.EgressoTest
    java -cp bin Teste.VisitanteTest
    java -cp bin Teste.EstagiarioTest

No VS Code: abra a pasta ProjetoTechAcademy e use "Run" em App.java ou nas classes de Teste.
